// Imports
const express = require('express')
const app = express()
const port = 25569

app.use(express.static('public'));
app.set('views', './public');
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
   res.sendFile(__dirname + '/public/index.html')
})
app.get('/pricing', (req, res) => {
   res.sendFile(__dirname + '/public/Pricing.html')
})
app.get('/privacy-policy', (req, res) => {
   res.sendFile(__dirname + '/public/pp.html')
})
app.get('/terms-of-service', (req, res) => {
   res.sendFile(__dirname + '/public/tos.html')
})
app.use(function (req, res) {
    res.status(404)
    res.sendFile(__dirname + '/public/404.html')
});
// Listen on Port 5000
app.listen(port, () => console.info(`App listening on port ${port}`))